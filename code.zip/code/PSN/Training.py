#this file trains the PSN model
from DataReader_Radar import RadarDataset
import torch
import torch.nn.functional as torchF
import numpy as np
import os
from Network import Classifier1D
import matplotlib.pyplot as plt
from sklearn import metrics

os.environ["CUDA_VISIBLE_DEVICES"] = '5'
np.random.seed(2)
decay = 4e-5

np.random.seed(1)
def validating( model, validationset, kind="val"):
	with torch.no_grad():  # close grad tracking to reduce memory consumption

		total_correct = 0
		total_samples = 0
		model.eval()
		#stacked = torch.tensor([], dtype=torch.int8)

		for batch in validationset:
			images, labels, _ = batch
			labels = labels.cuda()
			images = images.cuda()

			preds = model(images)
			total_correct += preds.argmax(dim=1).eq(labels).sum().item()

			total_samples += len(labels)

		val_acc = total_correct / total_samples
		print(kind + "_acc: ", total_correct / total_samples)
		# get confusion matrix elements [(labels, preds),...]#model.train()return val_acc

	return val_acc

def train(model,trainset_fall, trainset_notfall, valiset, epochs=50, lr=0.001, batch_size=64):
	optimizer = torch.optim.Adam(model.parameters(), lr, weight_decay=decay)
	lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
		optimizer, mode='max', factor=0.5, patience=10, verbose=True, min_lr=0.000001)
	best_acc = 0.0
	best_model = model
	#threshold = 0.5
	for epoch in range(epochs):
		model.eval()
		total_correct = 0
		total_samples = 0
		total_loss = 0

		for batch,batch_notfall in zip(trainset_fall, trainset_notfall):
			images, labels, imagesN = batch

			imagesN = imagesN.cuda()
			labels = labels.cuda()

			preds = model(imagesN)

			images_notfall, labels_notfall, imagesN_notfall = batch_notfall

			imagesN_notfall = imagesN_notfall.cuda()
			labels_notfall = labels_notfall.cuda()

			preds_notfall = model(imagesN_notfall)

			#print(preds.shape)
			# print(labels.shape)
			# print(preds.shape)


			loss_fall = torchF.cross_entropy(preds.squeeze(1), labels)
			loss_notfall = torchF.cross_entropy(preds_notfall.squeeze(1), labels_notfall)
			loss = loss_fall + loss_notfall
			#loss = torchF.binary_cross_entropy(preds.squeeze(1), labels.float())
			optimizer.zero_grad()
			loss.backward()
			optimizer.step()

			total_correct += preds.argmax(dim=1).eq(labels).sum().item() + \
			                 preds_notfall.argmax(dim=1).eq(labels_notfall).sum().item()
			# preds[ preds>=threshold ] = 1
			# preds[ preds<threshold ] = 0
			# total_correct += preds.eq(labels.float()).sum().item()

			total_samples += len(labels) + len(labels_notfall)
			total_loss += loss.item()

		acc = total_correct/total_samples #accuracy on training set
		print("epoch: ", epoch+1, "train_acc: ", acc, "total_loss: ", total_loss)
		val_acc = validating(model, valiset) ##accuracy on validation set
		#test_acc = validating(model, testset, kind="test")

		if val_acc > best_acc and val_acc > 0.97: #got new best accuracy
			best_model = model
			best_acc = val_acc
			print("save the model!!!!")
			#torch.save(model, "/home/jincheng/PycharmProjects/FLDetect/model_save/Newclf1.pth")

		lr_scheduler.step(val_acc)
		lr = optimizer.param_groups[0]['lr']
		print("best acc: ", best_acc)
		print('lr: ', lr)

	return best_model


def main():
	file_path_fall = '/home/shared_folders/AJC/STAGE2/train_set/fall'
	file_path_notfall = '/home/shared_folders/AJC/STAGE2/train_set/notfall'
	validate_file_path = '/home/shared_folders/AJC/STAGE2/validate_set'
	Dataset_fall = RadarDataset(file_path_fall, choice=False, noise=False) # do not add noise
	Dataset_notfall = RadarDataset(file_path_notfall, choice=False, noise=False)
	validate_dataset = RadarDataset(validate_file_path, choice=False, noise=False)
	#train_size = 2560
	#vlidate_size = len(Dataset) - train_size
	#validation_Dataset = RadarDataset(test_file_path, choice=False, noise=False)
	#train_set_split, validation_set_split = torch.utils.data.random_split(Dataset, [train_size, vlidate_size])

	batch_size = 128
	train_dataset_fall = torch.utils.data.DataLoader(Dataset_fall, batch_size=batch_size, shuffle=True)
	train_dataset_notfall = torch.utils.data.DataLoader(Dataset_notfall, batch_size=batch_size, shuffle=True)
	validaion_dataset = torch.utils.data.DataLoader(validate_dataset, batch_size=batch_size, shuffle=True)

	model = Classifier1D(input_channels=64).cuda()
	model.train()
	# model = train(model, train_dataset, validaion_dataset, new_dataset, epochs=150, lr=0.0001, batch_size=batch_size)
	# DrawROC(model, validaion_dataset)
	model = train(model, train_dataset_fall,train_dataset_notfall, validaion_dataset, epochs=200, lr=0.0001, batch_size=batch_size)
	#torch.save(model, "/home/jincheng/PycharmProjects/FLDetect/model_save/Newclassifier.pth")
if __name__ =="__main__":
	main()








