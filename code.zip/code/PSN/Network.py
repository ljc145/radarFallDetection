#this file defines our PSN model
import torch
import torch.nn as nn
import torch.nn.functional as torchF
import numpy as np

class Classifier1D(nn.Module):
	def __init__(self, input_channels=64, classes=2):
		super(Classifier1D, self).__init__()
		self.ch = input_channels
		self.classes = classes

		self.c1 = nn.Sequential(
			nn.Conv1d(in_channels=self.ch, out_channels=32, kernel_size=5, stride=2, padding=2),
			nn.BatchNorm1d(num_features=32),
			nn.ReLU(inplace=True),
		)
		self.c2 = nn.Sequential(
			nn.Conv1d(in_channels=self.ch, out_channels=32, kernel_size=5, stride=2, padding=2),
			nn.BatchNorm1d(num_features=32),
			nn.ReLU(inplace=True),
		)
		# self.c3 = nn.Sequential(
		# 	nn.Conv1d(in_channels=32, out_channels=64, kernel_size=5, stride=2, padding=2),
		# 	nn.BatchNorm1d(num_features=64),
		# 	nn.ReLU(inplace=True),
		# )
		# self.attention = nn.Sequential(
		# 	nn.Conv1d(in_channels=32, out_channels=64, kernel_size=5, stride=2, padding=2),
		# 	nn.BatchNorm1d(num_features=64),
		# 	#nn.ReLU(inplace=True),
		# 	nn.Tanh()
		# )
		self.classifier = nn.Sequential(
			nn.Dropout(p=0.5),
			nn.Linear(in_features=32*8, out_features=16), #64*8
			nn.BatchNorm1d(num_features=16),
			nn.ReLU(inplace=True),
			nn.Linear(in_features=16, out_features=self.classes),
			nn.Softmax(dim=1)
			#nn.Sigmoid()
		)
	def forward(self,x):
		#print(x.shape)
		x = torchF.adaptive_max_pool2d(x, 64) #64*64
		x1 = self.c1(x)
		x2 = self.c2(torch.transpose(x, 1, 2))
		#x = torch.cat((x1, x2), dim=1) #32*64
		x = torch.add(x1, x2) #32*32
		#x_a = self.attention(x)
		#x = self.c3(x)                  #64*16
		#x = torch.add(x, x_a)
		x = torchF.adaptive_max_pool1d(x, 8)
		x = x.view(-1, 32*8) #64*8
		#print(x.shape)
		out = self.classifier(x)

		return out

if __name__ == "__main__":
	C = Classifier1D(input_channels=64).cuda()
	x = torch.rand((64,128,128)).cuda()
	y = C(x)
	print(y.shape)