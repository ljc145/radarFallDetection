#this file reads data (radar spectrograms)
import numpy as np
import os
import torch
from torch.utils.data import Dataset, DataLoader
import torch.nn.functional as torchF
import matplotlib.pyplot as plt
np.random.seed(0)



class RadarDataset(Dataset):
    def __init__(self, file_path=0, path_len=None, CWdata=True, choice=True, noise=True): #choice=True: traing Generator
        self.file_path = file_path
        self.path_len = path_len
        self.CWdata = CWdata
        self.choice = choice
        self.noise = noise


        self.images, self.labels, self.noised, self.names = self.load_file2MFCC(self.file_path, self.path_len)


    def addGussianNoise(self,feature, mean=0, var=0.0001):
        feature_n = feature.copy()
        shape = feature_n.shape
        gnoise = np.random.normal(loc=mean, scale=var, size=shape)
        feature_n = feature_n + gnoise
        feature_n = 2 * (feature_n - np.min(feature_n)) / (np.max(feature_n) - np.min(feature_n)) - 1

        return feature_n



    def load_file2MFCC(self, file_path, path_len):
        origin_file_path = file_path
        wave_names = []
        wave_feature = []
        wave_noised = []
        labels = []


        #labsIndex = []
        for file_path, sub_dirs, filenames in os.walk(file_path):
            if filenames:  #there are files in root(file_path)
                filenames = sorted(np.array(filenames))
                for filename in filenames:
                    ###file_list.append(os.path.join(file_path, filename))
                    wave_names.append(file_path[path_len:] + '_' + filename)
                    print(filename)
                    feature = np.load(os.path.join(file_path, filename), allow_pickle=True)
                    # feature = feature[28:92, :]
                    # feature_f = np.sum(feature, axis=1)
                    # feature_f = 2 * (feature_f - np.min(feature_f)) / (np.max(feature_f) - np.min(feature_f)) - 1
                    # feature_t = np.sum(feature, axis=0)
                    # feature_t = 2 * (feature_t - np.min(feature_t)) / (np.max(feature_t) - np.min(feature_t)) - 1
                    # feature_t = feature_t[0::2,]
                    # feature = np.concatenate((feature_f, feature_t), axis=0)
                    if self.CWdata:
                        feature = feature.reshape(-1, 128)
                    #feature = feature[0,:,:]
                    # feature = 2*(feature-np.min(feature)) / (np.max(feature)-np.min(feature)) - 1 #scale to [-1,1]
                    #feature_df = self.deform(feature,self.L,self.W)
                    if self.noise:
                        #feature_noised = self.addNoise(feature, SNR=0.9)
                        feature_noised = self.addGussianNoise(feature)
                    else:
                        feature_noised = feature
                    #feature_df = feature_noised

                    wave_feature.append(feature)
                    wave_noised.append(feature_noised)
                    print("the number of file:", len(wave_feature))
                    #if (file_path.split('/'))[-1][:4] == 'fall':  #fall data
                    if (filename[:4]) == 'fall':
                        # if self.choice:     #trainging generator
                        #     if filename[:10] == 'fall_aside':
                        #         labels.append(0)
                        #
                        #     elif filename[0:12] == 'fall_forward':
                        #         labels.append(1)
                        #
                        #     else:
                        #         labels.append(2)
                        #     continue
                        labels.append(1)   #training classifier
                    # elif (filename[:4] == 'fake'):
                    #     labels.append(3)
                    # elif (not self.choice) and filename[0:3] == 'sit':
                    #     labels.append(1)
                    else:
                        # if self.choice:
                        #     if filename[0:4] == 'jump':
                        #         labels.append(4)
                        #     elif filename[0:3] == 'sit':
                        #         labels.append(5)
                        #     elif filename[0:5] == 'punch':
                        #         labels.append(6)
                        #     elif filename[0:5] == 'march':
                        #         labels.append(6)
                        #     elif filename[0:4] == 'walk':
                        #         labels.append(7)
                        #     else:
                        #         labels.append(8)
                        #
                        #     continue


                        labels.append(0)
                        continue
                    #labels.append(3)


        #shuffle the numpy, then convert into tensor
        wave_feature = np.array(wave_feature)
        labels = np.array(labels)
        wave_names = np.array(wave_names)
        wave_noised = np.array(wave_noised)

        ind_test = np.arange(len(labels))
        np.random.seed(1)
        np.random.shuffle(ind_test)
        wave_feature, labels, wave_noised ,wave_names = wave_feature[ind_test], labels[ind_test], wave_noised[ind_test],wave_names[ind_test]

        wave_feature = torch.Tensor(wave_feature)
        wave_noised = torch.Tensor(wave_noised)
        #labels = torch.Tensor(labels).long()  # 训练时需要labels为long型

        return wave_feature, labels, wave_noised, wave_names

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        return self.images[idx], self.labels[idx], self.noised[idx]

if __name__ == '__main__':

    file_path = '/home/shared_folders/AJC/STAGE2/train_set'

    dataset = RadarDataset(file_path, choice=False)
    print(type(dataset.noised))
    print(dataset.names.shape)
    print(dataset.noised.shape)
    plt.plot(dataset.images[2,0,:].reshape(128,))
    plt.show()
    print(dataset.labels[0:20])
