# this file trains the CRFD model
import os
import torch
import torch.nn.functional as torchF
import matplotlib.pyplot as plt
import numpy as np
import glob
from DataReader_Radar import RadarDataset
from Networks import Generator, GeneratorBN, Discriminator_ResNet18, GeneratorIN
np.random.seed(0)
os.environ["CUDA_VISIBLE_DEVICES"] = '5'

decay = 4e-5


def train_CRFD(g_model, d_model, Train_dataset,Train_dataset_other, Validate_dataset=None, epoches=50, alpha=0.03,beta=0,gamma=0.02,learningRate=0.001, batch_size=64):
    G_optimizer = torch.optim.Adam(g_model.parameters(), learningRate*3, weight_decay=decay) #IN lr*5    BN  lr*2
    G_lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        G_optimizer, mode='min', factor=0.5, patience=4, verbose=True, min_lr=0.000001)
    g_model.train()

    D_optimizer = torch.optim.Adam(d_model.parameters(), learningRate, weight_decay=decay)
    D_lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        D_optimizer, mode='min', factor=0.5, patience=5, verbose=True, min_lr=0.00001)
    d_model.train()
    croloss = torch.nn.CrossEntropyLoss()
    temp = torch.tensor([0],dtype = torch.float).cuda()
    #spectrograms used to observe the performance of the generator after each epoch
    jump_pic = np.load("/home/shared_folders/AJC/STAGE3/test_set/jump/jump81.npy").reshape(1,1,128,128)
    sit_pic = np.load("/home/shared_folders/AJC/STAGE3/test_set/sit/sit81.npy").reshape(1,1,128,128)
    jump_tensor = torch.Tensor(jump_pic).cuda()
    sit_tensor = torch.Tensor(sit_pic).cuda()

    min_g_loss = 10
    for epoch in range(epoches):
        g_loss_total = 0
        d_loss_total = 0
        g_loss_MSE_total = 0
        total_MSE_other = 0
        for (batch,batch_other ) in zip(Train_dataset, Train_dataset_other):

            image, label, imageN = batch  ## image.size = (64,1,128,128)
            image = image.cuda()
            imageN = imageN.cuda()

            label_true = torch.ones_like(label,dtype=torch.float).cuda()
            label_fake = torch.zeros_like(label,dtype=torch.float).cuda()
            label = label.cuda()

            image_other, _, imageN_other = batch_other  ## image.size = (64,1,128,128)

            image_other = image_other.cuda()
            imageN_other = imageN_other.cuda()


            ## train Generator
            fake_image, y_pre = g_model(imageN)  ### image 32x1x128x128
            g_result = d_model(fake_image)

            fake_image_other, _ = g_model(imageN_other)  ### image 32x1x128x128
            ### GAN loss + MeanSquare
            #g_loss_MSE = torchF.mse_loss(fake_image, image)
            dis_mtx_fake = torch.reshape(fake_image-image, (batch_size, -1))
            var_fake = torch.var(torch.norm(dis_mtx_fake, p=2, dim=1,), dim=0)   #for uniformity
            g_loss_MSE = torch.norm(fake_image-image, p=2) + var_fake   #mse means L2 Norm here


            dis_mtx_others = torch.reshape(fake_image_other - image_other,(batch_size, -1))
            var_others = torch.var(torch.norm(dis_mtx_others, p=2, dim=1,), dim=0)        #for uniformity

            MSE_other = torch.norm(fake_image_other - image_other, p=2)
            g_loss_MSE_other = torch.min(MSE_other-450, temp)  #T_error is set to 450
            g_loss_MSE_other = torch.abs(g_loss_MSE_other) + var_others   #BN 1


            g_loss_BCE = torchF.binary_cross_entropy(g_result.squeeze(1), label_true)
            g_loss_classify = croloss(y_pre.squeeze(1),label)

            g_loss = g_loss_BCE + alpha * g_loss_MSE  + beta * g_loss_classify + gamma * g_loss_MSE_other #IN 0.995   BN 0.97

            print('BCE:', g_loss_BCE.item(), '   MSE:', g_loss_MSE.item(), '   MSE_other:', g_loss_MSE_other.item())
            #### update generator
            G_optimizer.zero_grad()
            g_loss.backward()
            G_optimizer.step()

            #### criterion ####
            g_loss_total += g_loss.item()
            total_MSE_other  += g_loss_MSE_other.item()
            ### stop point ###
            g_loss_MSE_total += g_loss_MSE.item()

        ## train Discriminator
        d_real_result = d_model(image)
        d_loss_real = torchF.binary_cross_entropy(d_real_result.squeeze(1), label_true)
        #fake_image ,y_pre = g_model(imageN) ### image 64x1x128x128
        d_fake_result = d_model(fake_image.detach()) ## batch_sizexchannel
        d_loss_fake = torchF.binary_cross_entropy(d_fake_result.squeeze(1), label_fake)
        d_loss = d_loss_fake + d_loss_real

        #update Discriminator
        D_optimizer.zero_grad()
        d_loss.backward()
        D_optimizer.step()

        #### criterion ####
        d_loss_total += d_loss.item()
        mse_avg =  g_loss_MSE_total/ (1040//batch_size+1)
        # mse_avg_other = total_MSE_other /(1040//batch_size+1)

        #observe the performance of the generator after each epoch
        image , fake_image , d_fake_result ,d_real_result = image.cpu() ,fake_image.cpu(),d_fake_result.cpu(),d_real_result.cpu()
        image, fake_image, d_fake_result, d_real_result = image.detach().numpy() , fake_image.detach().numpy() , d_fake_result.detach().numpy() ,d_real_result.detach().numpy()
        fake_image_other = fake_image_other.cpu()
        fake_image_other = fake_image_other.detach().numpy()

        fake_jump, _ = g_model(jump_tensor)
        fake_jump = fake_jump.cpu().detach().numpy()
        fake_sit, _ = g_model(sit_tensor)
        fake_sit = fake_sit.cpu().detach().numpy()
        idx = np.random.randint(0, batch_size, 3) #the falls reconstructed by the genarator
        plt.subplot(3,3,1)
        plt.imshow(fake_image[idx[0]].reshape(128, 128), cmap='jet')
        plt.subplot(3,3,2)
        plt.imshow(fake_image[idx[1]].reshape(128, 128), cmap='jet')
        plt.subplot(3,3,3)
        plt.imshow(fake_image[idx[2]].reshape(128, 128), cmap='jet')
        plt.subplot(3,3,4)
        plt.imshow(fake_jump.reshape(128, 128), cmap='jet')
        plt.subplot(3,3,5)
        plt.imshow(fake_sit.reshape(128, 128), cmap='jet')
        plt.subplot(3,3,6)
        plt.imshow(fake_image_other[13].reshape(128, 128), cmap='jet')
        plt.pause(0.00001)

        #update learning rate
        G_lr_scheduler.step(g_loss_total)
        D_lr_scheduler.step(d_loss)
        print('Epoch:', epoch+1)
        print('learning rate: ', G_optimizer.state_dict()['param_groups'][0]['lr'])
        print('d_loss:', d_loss_total/batch_size, 'g_loss:', g_loss_total/batch_size ,'mse_avg:',mse_avg)
        if (g_loss_total/batch_size) < min_g_loss:
            min_g_loss = (g_loss_total/batch_size)
            #torch.save(g_model, '/home/jincheng/PycharmProjects/ACGAN/model_save/Generator/model_newG3.pth')
            print('----------------Model saved------------------')

    return g_model, d_model


def main():
    #file_path_fall_data = '/home/shared_folders/AJC/STAGE3/train_set/fall/'  #the train set with fake fall
    #file_path_other = '/home/shared_folders/AJC/STAGE3/train_set/notfall/'
    file_path_fall_data = '/home/shared_folders/AJC/STAGE3/train_set_notfakefall/fall' #the train set without fake fall
    file_path_other = '/home/shared_folders/AJC/STAGE3/train_set_notfakefall/notfall/'
    Dataset_other = RadarDataset(file_path_other, noise=True)
    Dataset = RadarDataset(file_path_fall_data, noise=True)


    ### split dataset
    batch_size = 32
    train_size = (len(Dataset)//batch_size)*batch_size
    validation_size = len(Dataset)-train_size

    validation_size_other = len(Dataset_other) - train_size
    train_set_split, validation_set_split = torch.utils.data.random_split(Dataset, [train_size, validation_size])
    train_set_split_other, validation_set_split_other = torch.utils.data.random_split(Dataset_other, [train_size, validation_size_other])
    ### load dataset

    train_dataset = torch.utils.data.DataLoader(train_set_split, batch_size=batch_size, shuffle=True)
    #validaion_dataset = torch.utils.data.DataLoader(validation_set_split, batch_size=batch_size, shuffle=True)
    train_dataset_other = torch.utils.data.DataLoader(train_set_split_other, batch_size=batch_size, shuffle=True)
    #validaion_dataset_other = torch.utils.data.DataLoader(validation_set_split_other, batch_size=batch_size, shuffle=True)
    ###start training
    #G = Generator(input_channels=1).cuda()
    G = GeneratorIN(input_channels=1).cuda()
    #G = torch.load('/home/jincheng/PycharmProjects/ACGAN/model_save/Generator/model_RCSIN2.pth').cuda()
    D = Discriminator_ResNet18(input_channels=1, num_classes=1).cuda()
    G_model, D_model = train_CRFD(G, D, train_dataset,train_dataset_other, alpha=0.046, gamma=0.026,   ### alpha0.06,beta4,gamma0.026  lr0.0002 G2
                             epoches=80, learningRate=0.002, batch_size=batch_size)


if __name__ == '__main__':
    main()