#this file defines our models
import torch
import torch.nn as nn
import torch.nn.functional as torchF
import numpy as np

class Generator(nn.Module):
    def __init__(self, input_channels,classes=3):
        super(Generator, self).__init__()
        self.input_channels=input_channels
        self.num_classes = classes
        self.g_encoder = nn.Sequential(
            ##5x5 input.shape(1,128,128)
            nn.Conv2d(in_channels=self.input_channels,out_channels=64, kernel_size=3,padding=1,stride=2), #/2
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3,padding=1,stride=1),
            #nn.BatchNorm2d(64),
            nn.InstanceNorm2d(64),
            nn.LeakyReLU(inplace=True),
            ##5x5 input(64,64,64)
            nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3,padding=1,stride=2),#/2
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3,padding=1, stride=1),
            #nn.BatchNorm2d(128),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(inplace=True),
            ##3x3 input(128,32,32)
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1,dilation=2),#dilated conv
            #nn.BatchNorm2d(128),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(inplace=True),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            #nn.BatchNorm2d(128),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(inplace=True),
            # nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            # nn.BatchNorm2d(128),
            # nn.LeakyReLU(inplace=True),
            # nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            # nn.BatchNorm2d(128),
            # nn.LeakyReLU(inplace=True),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
            #nn.BatchNorm2d(128),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(inplace=True),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
            #nn.BatchNorm2d(128),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(inplace=True),
            #nn.Conv2d(in_channels=256, out_channels=256, kernel_size=3,padding=1,stride=1)
            #nn.ReLU(inplace=True)
        #output(128,32,32)
        )
        self.classifier = nn.Sequential(
            nn.Linear(in_features=128*4*4, out_features=128),
            nn.LeakyReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(in_features=128, out_features=self.num_classes),
            #nn.Softmax(dim=2)
            nn.Softmax(dim=2)
        )
        self.g_decoder = nn.Sequential(
            ##3x3 output(128,8,8)
            #nn.Conv2d(in_channels=128*2, out_channels=128, kernel_size=1,padding=0,stride=1),
            #nn.ConvTranspose2d(in_channels=256,out_channels=128,padding=1,kernel_size=3,stride=1),
            #nn.ConvTranspose2d(in_channels=128, out_channels=128, padding=1, kernel_size=3, stride=2, output_padding=1),
            #nn.BatchNorm2d(128),
            #nn.LeakyReLU(inplace=True),
            ##5x5 output(64,16,16)
            nn.ConvTranspose2d(in_channels=128,out_channels=64,padding=1,kernel_size=3, stride=2, output_padding=1),#x2
            #nn.BatchNorm2d(64),
            nn.InstanceNorm2d(64),
            nn.LeakyReLU(inplace=True),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3,padding=1,stride=1),
            #nn.BatchNorm2d(64),
            nn.InstanceNorm2d(64),
            nn.LeakyReLU(inplace=True),
            ##5x5 output(32,32,32)
            #nn.ConvTranspose2d(in_channels=64,out_channels=32,padding=1,kernel_size=3,stride=2,output_padding=1),#x2
            #nn.ConvTranspose2d(in_channels=64,out_channels=32,padding=1,kernel_size=3,stride=1),
            #nn.BatchNorm2d(32),
            #nn.LeakyReLU(inplace=True),
            ##5x5 output(32,64,64)
            # nn.ConvTranspose2d(in_channels=32,out_channels=32,padding=1,kernel_size=3,stride=2,output_padding=1),#x2
            # nn.ConvTranspose2d(in_channels=32,out_channels=8,padding=1,kernel_size=3,stride=1),
            # #nn.BatchNorm2d(8),
            # nn.LeakyReLU(inplace=True),
            #nn.ReLu()#### necessarily?
            ## (1,128,128)
            nn.ConvTranspose2d(in_channels=64, out_channels=self.input_channels, padding=1, kernel_size=3, stride=2, output_padding=1),#x2
            nn.Tanh()
        )
        # self.attention_f = nn.Sequential(
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Softmax(dim=2)
        #     #nn.Tanh()
        # )
        # self.attention_t = nn.Sequential(
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Softmax(dim=3)
        # )
        
    def forward(self, image):
        image = self.g_encoder(image)
        image_a = torchF.max_pool2d(input=image, kernel_size=3,stride=2, padding=1)
        image_b = torchF.max_pool2d(input=image_a, kernel_size=3, stride=2, padding=1)
        image_c = torchF.max_pool2d(input=image_b, kernel_size=3, stride=2, padding=1)
        encode = image_c.view(-1, 1, 128*4*4)
        c_out = self.classifier(encode)
        # attention_t = self.attention_t(image)
        # attention_f = self.attention_f(image)
        # image_t = torch.mul(attention_t,image)
        # image_f = torch.mul(attention_f,image)
        # image = self.g_decoder(torch.cat((image_f + image_t, image), dim=1))
        image = self.g_decoder(image)
        return image, c_out

class GeneratorBN(nn.Module):
    def __init__(self, input_channels, classes=3):
        super(GeneratorBN, self).__init__()
        self.input_channels = input_channels
        self.num_classes = classes
        self.g_encoder = nn.Sequential(
            ##5x5 input.shape(1,128,128)
            nn.Conv2d(in_channels=self.input_channels, out_channels=64, kernel_size=3, padding=1, stride=2),  # /2
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(64),
            nn.LeakyReLU(inplace=True),
            ##5x5 input(64,64,64)
            nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, padding=1, stride=2),  # /2
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(inplace=True),
            ##3x3 input(128,32,32)
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),# dilated conv
            nn.BatchNorm2d(128),
            nn.LeakyReLU(inplace=True),

            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(inplace=True),
            # nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            # nn.BatchNorm2d(128),
            # nn.LeakyReLU(inplace=True),
            # nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            # nn.BatchNorm2d(128),
            # nn.LeakyReLU(inplace=True),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(inplace=True),

            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(inplace=True),
            # nn.Conv2d(in_channels=256, out_channels=256, kernel_size=3,padding=1,stride=1)
            # nn.ReLU(inplace=True)
            # output(128,32,32)
        )
        self.classifier = nn.Sequential(
            nn.Linear(in_features=128 * 4 * 4, out_features=128),
            nn.LeakyReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(in_features=128, out_features=self.num_classes),
            # nn.Softmax(dim=2)
            nn.Softmax(dim=2)
        )
        self.g_decoder = nn.Sequential(
            ##3x3 output(128,8,8)
            # nn.Conv2d(in_channels=128*2, out_channels=128, kernel_size=1,padding=0,stride=1),
            # nn.ConvTranspose2d(in_channels=256,out_channels=128,padding=1,kernel_size=3,stride=1),
            # nn.ConvTranspose2d(in_channels=128, out_channels=128, padding=1, kernel_size=3, stride=2, output_padding=1),
            # nn.BatchNorm2d(128),
            # nn.LeakyReLU(inplace=True),
            ##5x5 output(64,16,16)
            nn.ConvTranspose2d(in_channels=128, out_channels=64, padding=1, kernel_size=3, stride=2, output_padding=1),# x2
            nn.BatchNorm2d(64),
            nn.LeakyReLU(inplace=True),

            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(64),
            nn.LeakyReLU(inplace=True),
            ##5x5 output(32,32,32)
            # nn.ConvTranspose2d(in_channels=64,out_channels=32,padding=1,kernel_size=3,stride=2,output_padding=1),#x2
            # nn.ConvTranspose2d(in_channels=64,out_channels=32,padding=1,kernel_size=3,stride=1),
            # nn.BatchNorm2d(32),
            # nn.LeakyReLU(inplace=True),
            ##5x5 output(32,64,64)
            # nn.ConvTranspose2d(in_channels=32,out_channels=32,padding=1,kernel_size=3,stride=2,output_padding=1),#x2
            # nn.ConvTranspose2d(in_channels=32,out_channels=8,padding=1,kernel_size=3,stride=1),
            # #nn.BatchNorm2d(8),
            # nn.LeakyReLU(inplace=True),
            # nn.ReLu()#### necessarily?
            ## (1,128,128)
            nn.ConvTranspose2d(in_channels=64, out_channels=self.input_channels, padding=1, kernel_size=3, stride=2,
                               output_padding=1),  # x2
            nn.Tanh()
        )
        # self.attention_f = nn.Sequential(
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Softmax(dim=2)
        #     #nn.Tanh()
        # )
        # self.attention_t = nn.Sequential(
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Softmax(dim=3)
        # )

    def forward(self, image):
        image = self.g_encoder(image)
        image_a = torchF.max_pool2d(input=image, kernel_size=3, stride=2, padding=1)
        image_b = torchF.max_pool2d(input=image_a, kernel_size=3, stride=2, padding=1)
        image_c = torchF.max_pool2d(input=image_b, kernel_size=3, stride=2, padding=1)
        encode = image_c.view(-1, 1, 128 * 4 * 4)
        c_out = self.classifier(encode)
        # attention_t = self.attention_t(image)
        # attention_f = self.attention_f(image)
        # image_t = torch.mul(attention_t,image)
        # image_f = torch.mul(attention_f,image)
        # image = self.g_decoder(torch.cat((image_f + image_t, image), dim=1))
        image = self.g_decoder(image)
        return image, c_out

class GeneratorIN(nn.Module):
    def __init__(self, input_channels, classes=3):
        super(GeneratorIN, self).__init__()
        self.input_channels = input_channels
        self.num_classes = classes
        self.g_encoder = nn.Sequential(
            ##5x5 input.shape(1,128,128)
            nn.Conv2d(in_channels=self.input_channels, out_channels=64, kernel_size=3, padding=1, stride=2),  # /2
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, padding=1, stride=1),
            # nn.BatchNorm2d(64),
            nn.InstanceNorm2d(64),
            nn.LeakyReLU(inplace=True),
            ##5x5 input(64,64,64)
            nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, padding=1, stride=2),  # /2
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
            # nn.BatchNorm2d(128),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(inplace=True),
            ##3x3 input(128,32,32)
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            # dilated conv
            # nn.BatchNorm2d(128),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(inplace=True),
            #nn.Conv2d(in_channels=128, out_channels=128, kernel_size=4, padding=3, stride=1, dilation=2),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            # nn.BatchNorm2d(128),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(inplace=True),
            # nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            # nn.BatchNorm2d(128),
            # nn.LeakyReLU(inplace=True),
            # nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=2, stride=1, dilation=2),
            # nn.BatchNorm2d(128),
            # nn.LeakyReLU(inplace=True),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
            # nn.BatchNorm2d(128),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(inplace=True),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
            # nn.BatchNorm2d(128),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(inplace=True),
            # nn.Conv2d(in_channels=256, out_channels=256, kernel_size=3,padding=1,stride=1)
            # nn.ReLU(inplace=True)
            # output(128,32,32)
        )
        self.classifier = nn.Sequential(
            nn.Linear(in_features=128 * 4 * 4, out_features=128),
            nn.LeakyReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(in_features=128, out_features=self.num_classes),
            # nn.Softmax(dim=2)
            nn.Softmax(dim=2)
        )
        self.g_decoder = nn.Sequential(
            ##3x3 output(128,8,8)
            # nn.Conv2d(in_channels=128*2, out_channels=128, kernel_size=1,padding=0,stride=1),
            # nn.ConvTranspose2d(in_channels=256,out_channels=128,padding=1,kernel_size=3,stride=1),
            # nn.ConvTranspose2d(in_channels=128, out_channels=128, padding=1, kernel_size=3, stride=2, output_padding=1),
            # nn.BatchNorm2d(128),
            # nn.LeakyReLU(inplace=True),
            ##5x5 output(64,16,16)
            nn.ConvTranspose2d(in_channels=128, out_channels=64, padding=1, kernel_size=3, stride=2, output_padding=1),
            # x2
            # nn.BatchNorm2d(64),
            nn.InstanceNorm2d(64),
            nn.LeakyReLU(inplace=True),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, padding=1, stride=1),
            # nn.BatchNorm2d(64),
            nn.InstanceNorm2d(64),
            nn.LeakyReLU(inplace=True),
            ##5x5 output(32,32,32)
            # nn.ConvTranspose2d(in_channels=64,out_channels=32,padding=1,kernel_size=3,stride=2,output_padding=1),#x2
            # nn.ConvTranspose2d(in_channels=64,out_channels=32,padding=1,kernel_size=3,stride=1),
            # nn.BatchNorm2d(32),
            # nn.LeakyReLU(inplace=True),
            ##5x5 output(32,64,64)
            # nn.ConvTranspose2d(in_channels=32,out_channels=32,padding=1,kernel_size=3,stride=2,output_padding=1),#x2
            # nn.ConvTranspose2d(in_channels=32,out_channels=8,padding=1,kernel_size=3,stride=1),
            # #nn.BatchNorm2d(8),
            # nn.LeakyReLU(inplace=True),
            # nn.ReLu()#### necessarily?
            ## (1,128,128)
            nn.ConvTranspose2d(in_channels=64, out_channels=self.input_channels, padding=1, kernel_size=3, stride=2,
                               output_padding=1),  # x2
            nn.Tanh()
        )
        # self.attention_f = nn.Sequential(
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Softmax(dim=2)
        #     #nn.Tanh()
        # )
        # self.attention_t = nn.Sequential(
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1, stride=1),
        #     nn.Conv2d(in_channels=128, out_channels=128, kernel_size=1, padding=0, stride=1),
        #     nn.Softmax(dim=3)
        # )

    def forward(self, image):
        image = self.g_encoder(image)
        image_a = torchF.max_pool2d(input=image, kernel_size=3, stride=2, padding=1)
        image_b = torchF.max_pool2d(input=image_a, kernel_size=3, stride=2, padding=1)
        image_c = torchF.max_pool2d(input=image_b, kernel_size=3, stride=2, padding=1)
        encode = image_c.view(-1, 1, 128 * 4 * 4)
        c_out = self.classifier(encode)
        # attention_t = self.attention_t(image)
        # attention_f = self.attention_f(image)
        # image_t = torch.mul(attention_t,image)
        # image_f = torch.mul(attention_f,image)
        # image = self.g_decoder(torch.cat((image_f + image_t, image), dim=1))
        image = self.g_decoder(image)
        return image, c_out
class ResBlock(nn.Module):
    def __init__(self, input_channels, output_channels):
        super(ResBlock, self).__init__()
        self.input_channels = input_channels
        self.output_channels = output_channels
        
        self.Block_1 = nn.Sequential(
            nn.Conv2d(in_channels=self.input_channels,out_channels=self.output_channels,kernel_size=3,padding=1,stride=2),## /2
            nn.BatchNorm2d(self.output_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=self.output_channels,out_channels=self.output_channels,kernel_size=3,padding=1,stride=1)
            ##ouput(outChannel,/2,/2)
        )
        self.Block_2 = nn.Sequential(
            nn.Conv2d(in_channels=self.output_channels,out_channels=self.output_channels,kernel_size=3,padding=1,stride=1),## /2
            nn.BatchNorm2d(self.output_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=self.output_channels,out_channels=self.output_channels,kernel_size=3,padding=1,stride=1)
            ##ouput(outChannel,/2,/2)
        )
        self.shortcut = nn.Conv2d(in_channels=self.input_channels,out_channels=self.output_channels,kernel_size=1,stride=2)
        self.in_norm = nn.Sequential(
            nn.BatchNorm2d(self.input_channels),
            nn.ReLU(inplace=True)
        )
        self.mid_norm = nn.Sequential(
            nn.BatchNorm2d(self.output_channels),
            nn.ReLU(inplace=True)
        )
        
    def forward(self, image):
        image = self.in_norm(image)
        image_s = self.shortcut(image)
        image = self.Block_1(image)
        image = self.mid_norm(image_s+image)
        return self.Block_2(image)+image

class Discriminator_ResNet18(nn.Module):
    def __init__(self, input_channels, num_classes):
        super(Discriminator_ResNet18, self).__init__()
        self.input_channels = input_channels
        self.num_classes = num_classes
        self.d_Block_in = nn.Sequential( ## 5x5 input Block  output(32,64,64)
            nn.Conv2d(in_channels=self.input_channels,out_channels=32, kernel_size=3,padding=1,stride=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=32, out_channels=32, kernel_size=3,padding=1,stride=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=32, out_channels=32, kernel_size=3,padding=1,stride=1),
            nn.MaxPool2d(kernel_size=3,stride=2,padding=1)
        )
        self.Block64 = ResBlock(32,64)
        self.Block128 = ResBlock(64,128)
        self.Block256 = ResBlock(128,256)
        self.Block512 = ResBlock(256,512)
        self.classifier = nn.Sequential(
            #nn.AdaptiveAvgPool2d((2,2)),
            #nn.Flatten(),
            nn.Linear(in_features=512*2*2, out_features=256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(in_features=256, out_features=self.num_classes),
            nn.Sigmoid()
            #nn.Softmax(dim=1)
        )
        
    def forward(self, image):
        image = self.d_Block_in(image)
        image = self.Block64(image)
        image = self.Block128(image)
        image = self.Block256(image)
        image = self.Block512(image)
        image = torchF.adaptive_avg_pool2d(image, (2,2)).view(image.size(0),-1)
        image = self.classifier(image)
        return image




if __name__ == '__main__':
    #print(torch.__version__)
    x = np.random.randn(64,1,128,128)
    x = torch.tensor(x,dtype=torch.float32)
    g_model = Generator(1)
    y,classes = g_model(x)
    print(y.size(),classes.shape,classes[-1])
    
    d_model = Discriminator_ResNet18(input_channels=1, num_classes=2)
    z = d_model(y)
    print(z[3])