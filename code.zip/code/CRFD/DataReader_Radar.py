#this file helps to read radar spectrogram,size: 128*128
import numpy as np
import os
import torch
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
import glob
from EDFM import elastic_transform
os.environ["CUDA_VISIBLE_DEVICES"] = '5'
np.random.seed(1)
class RadarDataset(Dataset):
	def __init__(self, file_path=None, CWdata=True, choice=False, noise=False): #choice=True: traing Generator
		self.file_path = file_path
		self.CWdata = CWdata
		self.choice = choice
		self.noise = noise

		self.images, self.labels, self.noised = self.load_file2MFCC(self.file_path)

	def addGussianNoise(self,feature, mean=0, var=0.001):
		feature_n = feature.copy()
		shape = feature_n.shape
		gnoise = np.random.normal(loc=mean, scale=var, size=shape)
		feature_n = feature_n + gnoise
		feature_n = 2 * (feature_n - np.min(feature_n)) / (np.max(feature_n) - np.min(feature_n)) - 1

		return feature_n

	def load_file2MFCC(self, file_path):
		origin_file_path = file_path
		wave_names = []
		wave_feature = []
		wave_noised = []
		labels = []

		for file_path, sub_dirs, filenames in os.walk(file_path):

			if filenames:  #there are files in root(file_path)
				for filename in filenames:
					print(filename)
					feature = np.load(os.path.join(file_path, filename), allow_pickle=True)
					if self.CWdata:
						feature = feature.reshape(1, 128, 128)
					feature = 2*(feature-np.min(feature)) / (np.max(feature)-np.min(feature)) - 1   #scale to [-1,1]
					if self.noise:
						feature_noised = self.addGussianNoise(feature)   # add noise to data
					else:
						feature_noised = feature
					wave_feature.append(feature)
					wave_noised.append(feature_noised)
					print("the number of file:", len(wave_feature))
					if (filename[:4]) == 'fall':
						# if self.choice:     #trainging generator
						# 	if filename[:10] == 'fall_aside':
						# 		labels.append(0)
						#
						# 	elif filename[0:12] == 'fall_forward':
						# 		labels.append(1)
						# 	elif filename[:13] == 'fall_backward':
						# 		labels.append(2)
						#
						# 	else:
						# 		labels.append(3)
						# 	continue
						labels.append(1)   #training classifier
					else:
						# if self.choice:
						# 	if filename[:4] == 'fake':
						# 		labels.append(4)
						# 	elif filename[0:4] == 'jump':
						# 		labels.append(5)
						# 	elif filename[0:3] == 'sit':
						# 		labels.append(6)
						# 	elif filename[0:5] == 'punch':
						# 		labels.append(7)
						# 	elif filename[0:5] == 'march':
						# 		labels.append(8)
						# 	elif filename[:4] == 'walk':
						# 		labels.append(9)
						# 	elif filename[0:10] == 'walk_aside':
						# 		labels.append(10)
						# 	else:
						# 		#print(filename, ",,,,,,,,,,,,,,")
						# 		labels.append(11)
						# 	continue
						labels.append(0)

		wave_feature = np.array(wave_feature)
		labels = np.array(labels)
		wave_noised = np.array(wave_noised)

		ind_test = np.arange(len(labels))
		np.random.shuffle(ind_test)
		wave_feature, labels, wave_noised = wave_feature[ind_test], labels[ind_test], wave_noised[ind_test]

		wave_feature = torch.tensor(wave_feature, dtype=torch.float32)
		wave_noised = torch.tensor(wave_noised, dtype=torch.float32)

		return wave_feature, labels, wave_noised

	def __len__(self):
		return len(self.images)

	def __getitem__(self, idx):
		return self.images[idx], self.labels[idx], self.noised[idx]

if __name__ == '__main__':
	# generate 480 fake fall samples
	file_path = '/home/shared_folders/AJC/STAGE3/train_set/fall/'
	dataset = RadarDataset(file_path)
	# for i in range(1, 481):
	# 	imageA = dataset.images[i].detach().numpy().reshape(128, 128)
	# 	imageA = np.pad(imageA[1:-1, 1:-1], ((1, 1), (1, 1)), 'constant', constant_values=(-1, -1))
	# 	imageB = elastic_transform(imageA, 128*1, 128*0.08, 128*0.01)
	# 	np.save('/home/shared_folders/AJC/STAGE3/train_set/notfall/fake_fall/'+str(i), imageB)

	image1 = dataset.images[2,0,:,:].numpy().reshape(128, 128)  #show real fall and fake fall
	image2 = elastic_transform(image1, 128*1, 128*0.08, 128*0.01)
	print(image2.shape)
	plt.imshow(image1, cmap='jet')
	plt.show()
	plt.imshow(image2, cmap='jet')
	plt.show()